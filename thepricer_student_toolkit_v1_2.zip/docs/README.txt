ThePricer.org — Student Affordability Toolkit (SEAT) v1.2
Updated: 2025-10-23
License: CC BY 4.0 (see LICENSE-CCBY4.0.txt)
Contact: press@thepricer.org
Homepage: https://thepricer.org/student/resources/

WHAT THIS IS
A reproducible data pack and set of clean CSV templates that pair with the live
calculators at /student/resources/. Instructors can prefill these files for labs,
advising, or campus workshops. Students can audit our U.S. article and rebuild
the key figures from public sources.

FOLDER MAP
- datasets/   → Ready-to-use data behind the article and maps
- templates/  → Blank CSVs aligned to each calculator
- docs/       → Data dictionary and license

DATASETS (datasets/)
1) student_cost_national_cpi_1990_2019_2024_2025_v1.csv
   • CPI categories (NSA) and wage series at 1990-12, 2019-12, 2024-12, 2025-08
   • Series: CUUR0000SEHA (Rent), CUUR0000SEHF01 (Electricity), CUUR0000SEHF02 (Gas),
     CUUR0000SAF11 (Food at home), CUUR0000SETG (Public transportation),
     CUUR0000SAM2 (Medical care services), CUUR0000SA0 (All items CPI-U)
     Wage: CES7000000008 (Avg hrly earnings, Leisure & Hospitality, P&NS, USD/hr)

2) student_us_state_inputs_2025.csv
   • ACS 2023 median gross rent by state (B25064), CPI Rent scaler → 2025-08 est,
     state minimum wage 2025-01-01, and notes for split-rate states.

3) student_us_master_basket_v0.csv
   • 2025 baselines per category with CPI index levels and back-scaled dollar
     amounts (scaled_YYYY-MM_usd) plus a TOTAL row.

TEMPLATES (templates/)
- student_budget_template.csv            → Monthly student budget
- grocery_basket_template.csv            → Basic grocery cart
- country_student_cost_template.csv      → For later global comparisons (optional PPP)
- commute_cost_template.csv              → Car vs transit inputs
- meal_plan_template.csv                 → Plan vs groceries cost-per-meal
- roommate_split_template.csv            → Fair room split worksheet
- textbook_optimizer_template.csv        → Buy used vs rent vs eBook vs OER
- aid_impact_template.csv                → Grants/work-study impact
- student_state_template_acs_rent_minwage_2025.csv → Blank state sheet

METHODS (short)
- Hours-to-afford = monthly_total / (hourly_wage_after_tax)
- State rent hours = rent_2025_est / (state_min_wage_2025 × 0.92 net factor)
- Scaling past years uses CPI ratios: cost_year = cost_2025 × (index_year / index_2025)
- 2025 baselines match the live toolkit defaults to keep “calculator ↔ CSV” consistent.

PRIMARY SOURCES (verify latest):
- BLS CPI series pages and data tables for CUUR0000SEHA/SEHF01/SEHF02/SAF11/SETG/SAM2/SA0
- BLS CES (AHE) series CES7000000008
- Census Bureau ACS 1-year table B25064 (Median gross rent)
- U.S. DOL Consolidated State Minimum Wage (effective 2025-01-01)

CREDITS
© ThePricer.org — Please attribute “ThePricer.org – Student Affordability Toolkit (SEAT) v1.2”
with a link to https://thepricer.org/student/resources/ when sharing or remixing.

